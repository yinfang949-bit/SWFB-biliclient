.class public Lcom/RobinNotBad/BiliClient/api/PlayerApi;
.super Ljava/lang/Object;
.source "PlayerApi.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static synthetic a(Ljava/io/File;Ljava/lang/String;)Z
    .locals 0

    invoke-static {p0, p1}, Lcom/RobinNotBad/BiliClient/api/PlayerApi;->lambda$getSubtitleLinks$0(Ljava/io/File;Ljava/lang/String;)Z

    move-result p0

    return p0
.end method

.method public static getBangumi(Lcom/RobinNotBad/BiliClient/model/PlayerData;)V
    .locals 7

    .line 1
    new-instance v0, Lcom/RobinNotBad/BiliClient/util/NetWorkUtil$FormData;

    .line 2
    .line 3
    invoke-direct {v0}, Lcom/RobinNotBad/BiliClient/util/NetWorkUtil$FormData;-><init>()V

    .line 4
    .line 5
    .line 6
    const/4 v1, 0x1

    .line 7
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 8
    .line 9
    .line 10
    move-result-object v2

    .line 11
    invoke-virtual {v0, v1}, Lcom/RobinNotBad/BiliClient/util/NetWorkUtil$FormData;->setUrlParam(Z)Lcom/RobinNotBad/BiliClient/util/NetWorkUtil$FormData;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    iget-wide v3, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->aid:J

    .line 16
    .line 17
    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    const-string v3, "aid"

    .line 22
    .line 23
    invoke-virtual {v0, v3, v1}, Lcom/RobinNotBad/BiliClient/util/NetWorkUtil$FormData;->put(Ljava/lang/String;Ljava/lang/Object;)Lcom/RobinNotBad/BiliClient/util/NetWorkUtil$FormData;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    iget-wide v3, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->cid:J

    .line 28
    .line 29
    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    const-string v3, "cid"

    .line 34
    .line 35
    invoke-virtual {v0, v3, v1}, Lcom/RobinNotBad/BiliClient/util/NetWorkUtil$FormData;->put(Ljava/lang/String;Ljava/lang/Object;)Lcom/RobinNotBad/BiliClient/util/NetWorkUtil$FormData;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    const-string v1, "fnval"

    .line 40
    .line 41
    invoke-virtual {v0, v1, v2}, Lcom/RobinNotBad/BiliClient/util/NetWorkUtil$FormData;->put(Ljava/lang/String;Ljava/lang/Object;)Lcom/RobinNotBad/BiliClient/util/NetWorkUtil$FormData;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    const/4 v1, 0x0

    .line 46
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 47
    .line 48
    .line 49
    move-result-object v3

    .line 50
    const-string v4, "fnvar"

    .line 51
    .line 52
    invoke-virtual {v0, v4, v3}, Lcom/RobinNotBad/BiliClient/util/NetWorkUtil$FormData;->put(Ljava/lang/String;Ljava/lang/Object;)Lcom/RobinNotBad/BiliClient/util/NetWorkUtil$FormData;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    iget v3, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->qn:I

    .line 57
    .line 58
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 59
    .line 60
    .line 61
    move-result-object v3

    .line 62
    const-string v4, "qn"

    .line 63
    .line 64
    invoke-virtual {v0, v4, v3}, Lcom/RobinNotBad/BiliClient/util/NetWorkUtil$FormData;->put(Ljava/lang/String;Ljava/lang/Object;)Lcom/RobinNotBad/BiliClient/util/NetWorkUtil$FormData;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    const-string v3, "season_type"

    .line 69
    .line 70
    invoke-virtual {v0, v3, v2}, Lcom/RobinNotBad/BiliClient/util/NetWorkUtil$FormData;->put(Ljava/lang/String;Ljava/lang/Object;)Lcom/RobinNotBad/BiliClient/util/NetWorkUtil$FormData;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 75
    .line 76
    .line 77
    move-result-wide v2

    .line 78
    invoke-static {}, Landroid/os/SystemClock;->currentThreadTimeMillis()J

    .line 79
    .line 80
    .line 81
    move-result-wide v4

    .line 82
    sub-long/2addr v2, v4

    .line 83
    invoke-static {v2, v3}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object v2

    .line 87
    invoke-static {v2}, Lcom/RobinNotBad/BiliClient/util/ToolsUtil;->md5(Ljava/lang/String;)Ljava/lang/String;

    .line 88
    .line 89
    .line 90
    move-result-object v2

    .line 91
    const-string v3, "session"

    .line 92
    .line 93
    invoke-virtual {v0, v3, v2}, Lcom/RobinNotBad/BiliClient/util/NetWorkUtil$FormData;->put(Ljava/lang/String;Ljava/lang/Object;)Lcom/RobinNotBad/BiliClient/util/NetWorkUtil$FormData;

    .line 94
    .line 95
    .line 96
    move-result-object v0

    .line 97
    const-string v2, "platform"

    .line 98
    .line 99
    const-string v3, "pc"

    .line 100
    .line 101
    invoke-virtual {v0, v2, v3}, Lcom/RobinNotBad/BiliClient/util/NetWorkUtil$FormData;->put(Ljava/lang/String;Ljava/lang/Object;)Lcom/RobinNotBad/BiliClient/util/NetWorkUtil$FormData;

    .line 102
    .line 103
    .line 104
    move-result-object v0

    .line 105
    const-string v2, "https://api.bilibili.com/pgc/player/web/playurl"

    .line 106
    .line 107
    invoke-static {v2}, Landroidx/activity/e;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 108
    .line 109
    .line 110
    move-result-object v2

    .line 111
    invoke-virtual {v0}, Lcom/RobinNotBad/BiliClient/util/NetWorkUtil$FormData;->toString()Ljava/lang/String;

    .line 112
    .line 113
    .line 114
    move-result-object v0

    .line 115
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 116
    .line 117
    .line 118
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 119
    .line 120
    .line 121
    move-result-object v0

    .line 122
    invoke-static {v0}, Lcom/RobinNotBad/BiliClient/util/NetWorkUtil;->getJson(Ljava/lang/String;)Lorg/json/JSONObject;

    .line 123
    .line 124
    .line 125
    move-result-object v0

    .line 126
    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    .line 127
    .line 128
    .line 129
    move-result-object v2

    .line 130
    invoke-static {v2}, Lcom/RobinNotBad/BiliClient/util/Logu;->v(Ljava/lang/String;)V

    .line 131
    .line 132
    .line 133
    const-string v2, "result"

    .line 134
    .line 135
    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    .line 136
    .line 137
    .line 138
    move-result-object v0

    .line 139
    const-string v2, "durl"

    .line 140
    .line 141
    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    .line 142
    .line 143
    .line 144
    move-result-object v2

    .line 145
    invoke-virtual {v2, v1}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    .line 146
    .line 147
    .line 148
    move-result-object v2

    .line 149
    const-string v3, "url"

    .line 150
    .line 151
    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 152
    .line 153
    .line 154
    move-result-object v2

    .line 155
    iput-object v2, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->videoUrl:Ljava/lang/String;

    .line 156
    .line 157
    const-string v2, "https://comment.bilibili.com/"

    .line 158
    .line 159
    invoke-static {v2}, Landroidx/activity/e;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 160
    .line 161
    .line 162
    move-result-object v2

    .line 163
    iget-wide v3, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->cid:J

    .line 164
    .line 165
    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 166
    .line 167
    .line 168
    const-string v3, ".xml"

    .line 169
    .line 170
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 171
    .line 172
    .line 173
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 174
    .line 175
    .line 176
    move-result-object v2

    .line 177
    iput-object v2, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->danmakuUrl:Ljava/lang/String;

    .line 178
    .line 179
    const-string v2, "accept_description"

    .line 180
    .line 181
    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    .line 182
    .line 183
    .line 184
    move-result-object v2

    .line 185
    const-string v3, "accept_quality"

    .line 186
    .line 187
    invoke-virtual {v0, v3}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    .line 188
    .line 189
    .line 190
    move-result-object v0

    .line 191
    invoke-virtual {v2}, Lorg/json/JSONArray;->length()I

    .line 192
    .line 193
    .line 194
    move-result v3

    .line 195
    new-array v4, v3, [Ljava/lang/String;

    .line 196
    .line 197
    invoke-virtual {v2}, Lorg/json/JSONArray;->length()I

    .line 198
    .line 199
    .line 200
    move-result v5

    .line 201
    new-array v5, v5, [I

    .line 202
    .line 203
    :goto_0
    if-ge v1, v3, :cond_0

    .line 204
    .line 205
    invoke-virtual {v2, v1}, Lorg/json/JSONArray;->optString(I)Ljava/lang/String;

    .line 206
    .line 207
    .line 208
    move-result-object v6

    .line 209
    aput-object v6, v4, v1

    .line 210
    .line 211
    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->optInt(I)I

    .line 212
    .line 213
    .line 214
    move-result v6

    .line 215
    aput v6, v5, v1

    .line 216
    .line 217
    add-int/lit8 v1, v1, 0x1

    .line 218
    .line 219
    goto :goto_0

    .line 220
    :cond_0
    iput-object v4, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->qnStrList:[Ljava/lang/String;

    .line 221
    .line 222
    iput-object v5, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->qnValueList:[I

    .line 223
    .line 224
    return-void
.end method

.method public static getHighEnergyData(JJ)Lcom/RobinNotBad/BiliClient/model/HighEnergyData;
    .locals 5

    .line 1
    const-string v0, ""

    .line 2
    .line 3
    const-string v1, "\u9ad8\u80fd\u8fdb\u5ea6\u6761"

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    :try_start_0
    new-instance v3, Ljava/lang/StringBuilder;

    .line 7
    .line 8
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 9
    .line 10
    .line 11
    const-string v4, "https://bvc.bilivideo.com/pbp/data?cid="

    .line 12
    .line 13
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 14
    .line 15
    .line 16
    invoke-virtual {v3, p0, p1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 17
    .line 18
    .line 19
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    const-wide/16 v3, 0x0

    .line 24
    .line 25
    cmp-long p1, p2, v3

    .line 26
    .line 27
    if-lez p1, :cond_0

    .line 28
    .line 29
    new-instance p1, Ljava/lang/StringBuilder;

    .line 30
    .line 31
    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    .line 32
    .line 33
    .line 34
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 35
    .line 36
    .line 37
    const-string p0, "&aid="

    .line 38
    .line 39
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 40
    .line 41
    .line 42
    invoke-virtual {p1, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 43
    .line 44
    .line 45
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object p0

    .line 49
    :cond_0
    sget-object p1, Lcom/RobinNotBad/BiliClient/util/NetWorkUtil;->webHeaders:Ljava/util/ArrayList;

    .line 50
    .line 51
    invoke-static {p0, p1}, Lcom/RobinNotBad/BiliClient/util/NetWorkUtil;->getJson(Ljava/lang/String;Ljava/util/ArrayList;)Lorg/json/JSONObject;

    .line 52
    .line 53
    .line 54
    move-result-object p0

    .line 55
    if-nez p0, :cond_1

    .line 56
    .line 57
    const-string p0, "\u54cd\u5e94\u4e3a\u7a7a"

    .line 58
    .line 59
    invoke-static {v1, p0}, Lcom/RobinNotBad/BiliClient/util/Logu;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 60
    .line 61
    .line 62
    return-object v2

    .line 63
    :cond_1
    const-string p1, "code"

    .line 64
    .line 65
    const/4 p2, -0x1

    .line 66
    invoke-virtual {p0, p1, p2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    .line 67
    .line 68
    .line 69
    move-result p1

    .line 70
    if-eqz p1, :cond_2

    .line 71
    .line 72
    if-eq p1, p2, :cond_2

    .line 73
    .line 74
    new-instance p0, Ljava/lang/StringBuilder;

    .line 75
    .line 76
    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    .line 77
    .line 78
    .line 79
    const-string p2, "API\u8fd4\u56de\u9519\u8bef\u7801: "

    .line 80
    .line 81
    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 82
    .line 83
    .line 84
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 85
    .line 86
    .line 87
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 88
    .line 89
    .line 90
    move-result-object p0

    .line 91
    invoke-static {v1, p0}, Lcom/RobinNotBad/BiliClient/util/Logu;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 92
    .line 93
    .line 94
    return-object v2

    .line 95
    :cond_2
    new-instance p1, Lcom/RobinNotBad/BiliClient/model/HighEnergyData;

    .line 96
    .line 97
    invoke-direct {p1}, Lcom/RobinNotBad/BiliClient/model/HighEnergyData;-><init>()V

    .line 98
    .line 99
    .line 100
    const-string p2, "step_sec"

    .line 101
    .line 102
    const/16 p3, 0xa

    .line 103
    .line 104
    invoke-virtual {p0, p2, p3}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    .line 105
    .line 106
    .line 107
    move-result p2

    .line 108
    iput p2, p1, Lcom/RobinNotBad/BiliClient/model/HighEnergyData;->stepSec:I

    .line 109
    .line 110
    const-string p2, "tagstr"

    .line 111
    .line 112
    invoke-virtual {p0, p2, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 113
    .line 114
    .line 115
    move-result-object p2

    .line 116
    iput-object p2, p1, Lcom/RobinNotBad/BiliClient/model/HighEnergyData;->tagStr:Ljava/lang/String;

    .line 117
    .line 118
    const-string p2, "debug"

    .line 119
    .line 120
    invoke-virtual {p0, p2, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 121
    .line 122
    .line 123
    move-result-object p2

    .line 124
    iput-object p2, p1, Lcom/RobinNotBad/BiliClient/model/HighEnergyData;->debug:Ljava/lang/String;

    .line 125
    .line 126
    const-string p2, "events"

    .line 127
    .line 128
    invoke-virtual {p0, p2}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    .line 129
    .line 130
    .line 131
    move-result-object p0

    .line 132
    const/4 p2, 0x0

    .line 133
    if-eqz p0, :cond_5

    .line 134
    .line 135
    const-string p3, "default"

    .line 136
    .line 137
    invoke-virtual {p0, p3}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    .line 138
    .line 139
    .line 140
    move-result-object p0

    .line 141
    if-eqz p0, :cond_4

    .line 142
    .line 143
    invoke-virtual {p0}, Lorg/json/JSONArray;->length()I

    .line 144
    .line 145
    .line 146
    move-result p3

    .line 147
    if-lez p3, :cond_4

    .line 148
    .line 149
    invoke-virtual {p0}, Lorg/json/JSONArray;->length()I

    .line 150
    .line 151
    .line 152
    move-result p3

    .line 153
    new-array v0, p3, [F

    .line 154
    .line 155
    :goto_0
    invoke-virtual {p0}, Lorg/json/JSONArray;->length()I

    .line 156
    .line 157
    .line 158
    move-result v3

    .line 159
    if-ge p2, v3, :cond_3

    .line 160
    .line 161
    const-wide/16 v3, 0x0

    .line 162
    .line 163
    invoke-virtual {p0, p2, v3, v4}, Lorg/json/JSONArray;->optDouble(ID)D

    .line 164
    .line 165
    .line 166
    move-result-wide v3

    .line 167
    double-to-float v3, v3

    .line 168
    aput v3, v0, p2

    .line 169
    .line 170
    add-int/lit8 p2, p2, 0x1

    .line 171
    .line 172
    goto :goto_0

    .line 173
    :cond_3
    iput-object v0, p1, Lcom/RobinNotBad/BiliClient/model/HighEnergyData;->events:[F

    .line 174
    .line 175
    new-instance p0, Ljava/lang/StringBuilder;

    .line 176
    .line 177
    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    .line 178
    .line 179
    .line 180
    const-string p2, "\u6210\u529f\u83b7\u53d6 "

    .line 181
    .line 182
    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 183
    .line 184
    .line 185
    invoke-virtual {p0, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 186
    .line 187
    .line 188
    const-string p2, " \u4e2a\u6570\u636e\u70b9\uff0c\u91c7\u6837\u95f4\u9694: "

    .line 189
    .line 190
    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 191
    .line 192
    .line 193
    iget p2, p1, Lcom/RobinNotBad/BiliClient/model/HighEnergyData;->stepSec:I

    .line 194
    .line 195
    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 196
    .line 197
    .line 198
    const-string p2, "\u79d2"

    .line 199
    .line 200
    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 201
    .line 202
    .line 203
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 204
    .line 205
    .line 206
    move-result-object p0

    .line 207
    invoke-static {v1, p0}, Lcom/RobinNotBad/BiliClient/util/Logu;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 208
    .line 209
    .line 210
    goto :goto_1

    .line 211
    :cond_4
    const-string p0, "default\u6570\u7ec4\u4e3a\u7a7a\u6216\u4e0d\u5b58\u5728"

    .line 212
    .line 213
    invoke-static {v1, p0}, Lcom/RobinNotBad/BiliClient/util/Logu;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 214
    .line 215
    .line 216
    new-array p0, p2, [F

    .line 217
    .line 218
    iput-object p0, p1, Lcom/RobinNotBad/BiliClient/model/HighEnergyData;->events:[F

    .line 219
    .line 220
    goto :goto_1

    .line 221
    :cond_5
    const-string p0, "events\u5bf9\u8c61\u4e0d\u5b58\u5728"

    .line 222
    .line 223
    invoke-static {v1, p0}, Lcom/RobinNotBad/BiliClient/util/Logu;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 224
    .line 225
    .line 226
    new-array p0, p2, [F

    .line 227
    .line 228
    iput-object p0, p1, Lcom/RobinNotBad/BiliClient/model/HighEnergyData;->events:[F
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 229
    .line 230
    :goto_1
    return-object p1

    .line 231
    :catch_0
    move-exception p0

    .line 232
    const-string p1, "\u83b7\u53d6\u5931\u8d25: "

    .line 233
    .line 234
    invoke-static {p1}, Landroidx/activity/e;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 235
    .line 236
    .line 237
    move-result-object p1

    .line 238
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 239
    .line 240
    .line 241
    move-result-object p2

    .line 242
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 243
    .line 244
    .line 245
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 246
    .line 247
    .line 248
    move-result-object p1

    .line 249
    invoke-static {v1, p1}, Lcom/RobinNotBad/BiliClient/util/Logu;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 250
    .line 251
    .line 252
    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 253
    .line 254
    .line 255
    return-object v2
.end method

.method public static getInteractionGraphVersion(JJ)J
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 4
    .line 5
    .line 6
    const-string v1, "https://api.bilibili.com/x/player/wbi/v2?aid="

    .line 7
    .line 8
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 9
    .line 10
    .line 11
    invoke-virtual {v0, p0, p1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 12
    .line 13
    .line 14
    const-string p0, "&cid="

    .line 15
    .line 16
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 17
    .line 18
    .line 19
    invoke-virtual {v0, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 20
    .line 21
    .line 22
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    invoke-static {p0}, Lcom/RobinNotBad/BiliClient/api/ConfInfoApi;->signWBI(Ljava/lang/String;)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object p0

    .line 30
    invoke-static {p0}, Lcom/RobinNotBad/BiliClient/util/NetWorkUtil;->getJson(Ljava/lang/String;)Lorg/json/JSONObject;

    .line 31
    .line 32
    .line 33
    move-result-object p0

    .line 34
    const-string p1, "data"

    .line 35
    .line 36
    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    .line 37
    .line 38
    .line 39
    move-result-object p0

    .line 40
    const-string p1, "interaction"

    .line 41
    .line 42
    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    .line 43
    .line 44
    .line 45
    move-result p2

    .line 46
    if-eqz p2, :cond_0

    .line 47
    .line 48
    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    .line 49
    .line 50
    .line 51
    move-result p2

    .line 52
    if-nez p2, :cond_0

    .line 53
    .line 54
    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    .line 55
    .line 56
    .line 57
    move-result-object p0

    .line 58
    const-string p1, "graph_version"

    .line 59
    .line 60
    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    .line 61
    .line 62
    .line 63
    move-result p2

    .line 64
    if-eqz p2, :cond_0

    .line 65
    .line 66
    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->getLong(Ljava/lang/String;)J

    .line 67
    .line 68
    .line 69
    move-result-wide p0

    .line 70
    return-wide p0

    .line 71
    :cond_0
    const-wide/16 p0, 0x0

    .line 72
    .line 73
    return-wide p0
.end method

.method public static getSubtitle(Ljava/io/File;)[Lcom/RobinNotBad/BiliClient/model/Subtitle;
    .locals 10

    .line 9
    invoke-static {p0}, Lcom/RobinNotBad/BiliClient/util/FileUtil;->readString(Ljava/io/File;)Ljava/lang/String;

    move-result-object p0

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    .line 10
    :cond_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string p0, "body"

    invoke-virtual {v0, p0}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p0

    .line 11
    invoke-virtual {p0}, Lorg/json/JSONArray;->length()I

    move-result v0

    new-array v0, v0, [Lcom/RobinNotBad/BiliClient/model/Subtitle;

    const/4 v1, 0x0

    .line 12
    :goto_0
    invoke-virtual {p0}, Lorg/json/JSONArray;->length()I

    move-result v2

    if-ge v1, v2, :cond_1

    .line 13
    invoke-virtual {p0, v1}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v2

    .line 14
    new-instance v9, Lcom/RobinNotBad/BiliClient/model/Subtitle;

    const-string v3, "content"

    .line 15
    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v3, "from"

    .line 16
    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->getDouble(Ljava/lang/String;)D

    move-result-wide v5

    const-string v3, "to"

    .line 17
    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->getDouble(Ljava/lang/String;)D

    move-result-wide v7

    move-object v3, v9

    invoke-direct/range {v3 .. v8}, Lcom/RobinNotBad/BiliClient/model/Subtitle;-><init>(Ljava/lang/String;DD)V

    aput-object v9, v0, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return-object v0
.end method

.method public static getSubtitle(Ljava/lang/String;)[Lcom/RobinNotBad/BiliClient/model/Subtitle;
    .locals 10

    .line 1
    invoke-static {p0}, Lcom/RobinNotBad/BiliClient/util/NetWorkUtil;->getJson(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p0

    const-string v0, "body"

    invoke-virtual {p0, v0}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p0

    .line 2
    invoke-virtual {p0}, Lorg/json/JSONArray;->length()I

    move-result v0

    new-array v0, v0, [Lcom/RobinNotBad/BiliClient/model/Subtitle;

    const/4 v1, 0x0

    .line 3
    :goto_0
    invoke-virtual {p0}, Lorg/json/JSONArray;->length()I

    move-result v2

    if-ge v1, v2, :cond_0

    .line 4
    invoke-virtual {p0, v1}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v2

    .line 5
    new-instance v9, Lcom/RobinNotBad/BiliClient/model/Subtitle;

    const-string v3, "content"

    .line 6
    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v3, "from"

    .line 7
    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->getDouble(Ljava/lang/String;)D

    move-result-wide v5

    const-string v3, "to"

    .line 8
    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->getDouble(Ljava/lang/String;)D

    move-result-wide v7

    move-object v3, v9

    invoke-direct/range {v3 .. v8}, Lcom/RobinNotBad/BiliClient/model/Subtitle;-><init>(Ljava/lang/String;DD)V

    aput-object v9, v0, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    return-object v0
.end method

.method public static getSubtitleLinks(JJ)[Lcom/RobinNotBad/BiliClient/model/SubtitleLink;
    .locals 8

    .line 6
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "https://api.bilibili.com/x/player/wbi/v2?aid="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0, p1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string p0, "&cid="

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    .line 7
    invoke-static {p0}, Lcom/RobinNotBad/BiliClient/api/ConfInfoApi;->signWBI(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    .line 8
    invoke-static {p0}, Lcom/RobinNotBad/BiliClient/util/NetWorkUtil;->getJson(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p0

    const-string p1, "data"

    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p0

    const-string p1, "subtitle"

    .line 9
    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p0

    const-string p2, "subtitles"

    invoke-virtual {p0, p2}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p0

    .line 10
    invoke-virtual {p0}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-static {p1, p2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 11
    invoke-virtual {p0}, Lorg/json/JSONArray;->length()I

    move-result p1

    const/4 p2, 0x1

    add-int/2addr p1, p2

    new-array p1, p1, [Lcom/RobinNotBad/BiliClient/model/SubtitleLink;

    const/4 p3, 0x0

    .line 12
    :goto_0
    invoke-virtual {p0}, Lorg/json/JSONArray;->length()I

    move-result v0

    if-ge p3, v0, :cond_1

    .line 13
    invoke-virtual {p0, p3}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v0

    const-string v1, "id"

    .line 14
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getLong(Ljava/lang/String;)J

    move-result-wide v3

    const-string v1, "type"

    .line 15
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v1

    if-ne v1, p2, :cond_0

    const/4 v1, 0x1

    const/4 v7, 0x1

    goto :goto_1

    :cond_0
    const/4 v1, 0x0

    const/4 v7, 0x0

    :goto_1
    const-string v1, "lan_doc"

    .line 16
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v1, "https:"

    .line 17
    invoke-static {v1}, Landroidx/activity/e;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "subtitle_url"

    .line 18
    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    .line 19
    new-instance v0, Lcom/RobinNotBad/BiliClient/model/SubtitleLink;

    move-object v2, v0

    invoke-direct/range {v2 .. v7}, Lcom/RobinNotBad/BiliClient/model/SubtitleLink;-><init>(JLjava/lang/String;Ljava/lang/String;Z)V

    .line 20
    aput-object v0, p1, p3

    add-int/lit8 p3, p3, 0x1

    goto :goto_0

    .line 21
    :cond_1
    invoke-virtual {p0}, Lorg/json/JSONArray;->length()I

    move-result p0

    new-instance p2, Lcom/RobinNotBad/BiliClient/model/SubtitleLink;

    const-wide/16 v1, -0x1

    const/4 v5, 0x0

    const-string v3, "\u4e0d\u663e\u793a\u5b57\u5e55"

    const-string v4, "null"

    move-object v0, p2

    invoke-direct/range {v0 .. v5}, Lcom/RobinNotBad/BiliClient/model/SubtitleLink;-><init>(JLjava/lang/String;Ljava/lang/String;Z)V

    aput-object p2, p1, p0

    return-object p1
.end method

.method public static getSubtitleLinks(Ljava/io/File;)[Lcom/RobinNotBad/BiliClient/model/SubtitleLink;
    .locals 11

    .line 1
    new-instance v0, Lcom/RobinNotBad/BiliClient/api/a;

    invoke-direct {v0}, Lcom/RobinNotBad/BiliClient/api/a;-><init>()V

    invoke-virtual {p0, v0}, Ljava/io/File;->listFiles(Ljava/io/FilenameFilter;)[Ljava/io/File;

    move-result-object p0

    const/4 v0, 0x1

    if-eqz p0, :cond_0

    .line 2
    array-length v1, p0

    add-int/2addr v1, v0

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    :goto_0
    new-array v2, v1, [Lcom/RobinNotBad/BiliClient/model/SubtitleLink;

    if-eqz p0, :cond_1

    const/4 v3, 0x0

    .line 3
    :goto_1
    array-length v4, p0

    if-ge v3, v4, :cond_1

    .line 4
    new-instance v4, Lcom/RobinNotBad/BiliClient/model/SubtitleLink;

    int-to-long v6, v3

    aget-object v5, p0, v3

    invoke-virtual {v5}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v8

    aget-object v5, p0, v3

    invoke-virtual {v5}, Ljava/io/File;->toString()Ljava/lang/String;

    move-result-object v9

    const/4 v10, 0x0

    move-object v5, v4

    invoke-direct/range {v5 .. v10}, Lcom/RobinNotBad/BiliClient/model/SubtitleLink;-><init>(JLjava/lang/String;Ljava/lang/String;Z)V

    aput-object v4, v2, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :cond_1
    sub-int/2addr v1, v0

    .line 5
    new-instance p0, Lcom/RobinNotBad/BiliClient/model/SubtitleLink;

    const-wide/16 v4, -0x1

    const/4 v8, 0x0

    const-string v6, "\u4e0d\u663e\u793a\u5b57\u5e55"

    const-string v7, "null"

    move-object v3, p0

    invoke-direct/range {v3 .. v8}, Lcom/RobinNotBad/BiliClient/model/SubtitleLink;-><init>(JLjava/lang/String;Ljava/lang/String;Z)V

    aput-object p0, v2, v1

    return-object v2
.end method

.method public static getVideo(Lcom/RobinNotBad/BiliClient/model/PlayerData;Z)V
    .locals 6

    .line 1
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 2
    .line 3
    .line 4
    move-result-wide v0

    .line 5
    iget-wide v2, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->timeStamp:J

    .line 6
    .line 7
    sub-long/2addr v0, v2

    .line 8
    const-wide/32 v2, 0x927c0

    .line 9
    .line 10
    .line 11
    cmp-long v4, v0, v2

    .line 12
    .line 13
    if-gez v4, :cond_0

    .line 14
    .line 15
    return-void

    .line 16
    :cond_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 17
    .line 18
    .line 19
    move-result-wide v0

    .line 20
    iput-wide v0, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->timeStamp:J

    .line 21
    .line 22
    const-string v0, "https://comment.bilibili.com/"

    .line 23
    .line 24
    invoke-static {v0}, Landroidx/activity/e;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    iget-wide v1, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->cid:J

    .line 29
    .line 30
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 31
    .line 32
    .line 33
    const-string v1, ".xml"

    .line 34
    .line 35
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 36
    .line 37
    .line 38
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    iput-object v0, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->danmakuUrl:Ljava/lang/String;

    .line 43
    .line 44
    const-string v0, ""

    .line 45
    .line 46
    const/4 v1, 0x0

    .line 47
    if-nez p1, :cond_1

    .line 48
    .line 49
    const-string p1, "player"

    .line 50
    .line 51
    invoke-static {p1, v0}, Lcom/RobinNotBad/BiliClient/util/SharedPreferencesUtil;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    const-string v2, "mtvPlayer"

    .line 56
    .line 57
    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    move-result p1

    .line 61
    if-eqz p1, :cond_1

    .line 62
    .line 63
    const/4 p1, 0x1

    .line 64
    goto :goto_0

    .line 65
    :cond_1
    const/4 p1, 0x0

    .line 66
    :goto_0
    const-string v2, "https://api.bilibili.com/x/player/wbi/playurl?avid="

    .line 67
    .line 68
    invoke-static {v2}, Landroidx/activity/e;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 69
    .line 70
    .line 71
    move-result-object v2

    .line 72
    iget-wide v3, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->aid:J

    .line 73
    .line 74
    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 75
    .line 76
    .line 77
    const-string v3, "&cid="

    .line 78
    .line 79
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 80
    .line 81
    .line 82
    iget-wide v3, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->cid:J

    .line 83
    .line 84
    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 85
    .line 86
    .line 87
    if-eqz p1, :cond_2

    .line 88
    .line 89
    const-string v0, "&high_quality=1"

    .line 90
    .line 91
    :cond_2
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 92
    .line 93
    .line 94
    const-string v0, "&qn="

    .line 95
    .line 96
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 97
    .line 98
    .line 99
    iget v0, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->qn:I

    .line 100
    .line 101
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 102
    .line 103
    .line 104
    const-string v0, "&fnval=1&fnver=0&platform="

    .line 105
    .line 106
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 107
    .line 108
    .line 109
    if-eqz p1, :cond_3

    .line 110
    .line 111
    const-string p1, "html5"

    .line 112
    .line 113
    goto :goto_1

    .line 114
    :cond_3
    const-string p1, "pc"

    .line 115
    .line 116
    :goto_1
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 117
    .line 118
    .line 119
    const-string p1, "&voice_balance=1&gaia_source=pre-load&isGaiaAvoided=true"

    .line 120
    .line 121
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 122
    .line 123
    .line 124
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 125
    .line 126
    .line 127
    move-result-object p1

    .line 128
    invoke-static {p1}, Lcom/RobinNotBad/BiliClient/api/ConfInfoApi;->signWBI(Ljava/lang/String;)Ljava/lang/String;

    .line 129
    .line 130
    .line 131
    move-result-object p1

    .line 132
    sget-object v0, Lcom/RobinNotBad/BiliClient/util/NetWorkUtil;->webHeaders:Ljava/util/ArrayList;

    .line 133
    .line 134
    invoke-static {p1, v0}, Lcom/RobinNotBad/BiliClient/util/NetWorkUtil;->getJson(Ljava/lang/String;Ljava/util/ArrayList;)Lorg/json/JSONObject;

    .line 135
    .line 136
    .line 137
    move-result-object p1

    .line 138
    const-string v0, "data"

    .line 139
    .line 140
    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    .line 141
    .line 142
    .line 143
    move-result-object p1

    .line 144
    const-string v0, "durl"

    .line 145
    .line 146
    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    .line 147
    .line 148
    .line 149
    move-result-object v0

    .line 150
    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    .line 151
    .line 152
    .line 153
    move-result-object v0

    .line 154
    const-string v2, "url"

    .line 155
    .line 156
    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 157
    .line 158
    .line 159
    move-result-object v0

    .line 160
    iput-object v0, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->videoUrl:Ljava/lang/String;

    .line 161
    .line 162
    const-string v0, "last_play_cid"

    .line 163
    .line 164
    const-wide/16 v2, 0x0

    .line 165
    .line 166
    invoke-virtual {p1, v0, v2, v3}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    .line 167
    .line 168
    .line 169
    move-result-wide v4

    .line 170
    iput-wide v4, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->cidHistory:J

    .line 171
    .line 172
    const-string v0, "last_play_time"

    .line 173
    .line 174
    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    .line 175
    .line 176
    .line 177
    move-result v0

    .line 178
    iput v0, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->progress:I

    .line 179
    .line 180
    iget-wide v4, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->cidHistory:J

    .line 181
    .line 182
    cmp-long v0, v4, v2

    .line 183
    .line 184
    if-nez v0, :cond_4

    .line 185
    .line 186
    iget-wide v2, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->cid:J

    .line 187
    .line 188
    iput-wide v2, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->cidHistory:J

    .line 189
    .line 190
    iput v1, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->progress:I

    .line 191
    .line 192
    :cond_4
    new-instance v0, Ljava/lang/StringBuilder;

    .line 193
    .line 194
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 195
    .line 196
    .line 197
    iget v2, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->progress:I

    .line 198
    .line 199
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 200
    .line 201
    .line 202
    const-string v2, ","

    .line 203
    .line 204
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 205
    .line 206
    .line 207
    iget-wide v2, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->cidHistory:J

    .line 208
    .line 209
    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 210
    .line 211
    .line 212
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 213
    .line 214
    .line 215
    move-result-object v0

    .line 216
    const-string v2, "history"

    .line 217
    .line 218
    invoke-static {v2, v0}, Lcom/RobinNotBad/BiliClient/util/Logu;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 219
    .line 220
    .line 221
    const-string v0, "accept_description"

    .line 222
    .line 223
    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    .line 224
    .line 225
    .line 226
    move-result-object v0

    .line 227
    const-string v2, "accept_quality"

    .line 228
    .line 229
    invoke-virtual {p1, v2}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    .line 230
    .line 231
    .line 232
    move-result-object p1

    .line 233
    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    .line 234
    .line 235
    .line 236
    move-result v2

    .line 237
    new-array v3, v2, [Ljava/lang/String;

    .line 238
    .line 239
    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    .line 240
    .line 241
    .line 242
    move-result v4

    .line 243
    new-array v4, v4, [I

    .line 244
    .line 245
    :goto_2
    if-ge v1, v2, :cond_5

    .line 246
    .line 247
    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->optString(I)Ljava/lang/String;

    .line 248
    .line 249
    .line 250
    move-result-object v5

    .line 251
    aput-object v5, v3, v1

    .line 252
    .line 253
    invoke-virtual {p1, v1}, Lorg/json/JSONArray;->optInt(I)I

    .line 254
    .line 255
    .line 256
    move-result v5

    .line 257
    aput v5, v4, v1

    .line 258
    .line 259
    add-int/lit8 v1, v1, 0x1

    .line 260
    .line 261
    goto :goto_2

    .line 262
    :cond_5
    invoke-static {v3}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    .line 263
    .line 264
    .line 265
    move-result-object p1

    .line 266
    const-string v0, "qn_str"

    .line 267
    .line 268
    invoke-static {v0, p1}, Lcom/RobinNotBad/BiliClient/util/Logu;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 269
    .line 270
    .line 271
    invoke-static {v4}, Ljava/util/Arrays;->toString([I)Ljava/lang/String;

    .line 272
    .line 273
    .line 274
    move-result-object p1

    .line 275
    const-string v0, "qn_val"

    .line 276
    .line 277
    invoke-static {v0, p1}, Lcom/RobinNotBad/BiliClient/util/Logu;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 278
    .line 279
    .line 280
    iput-object v3, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->qnStrList:[Ljava/lang/String;

    .line 281
    .line 282
    iput-object v4, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->qnValueList:[I

    .line 283
    .line 284
    return-void
.end method

.method public static getVideoDash(Lcom/RobinNotBad/BiliClient/model/PlayerData;)V
    .locals 7

    .line 1
    const-string v0, "https://comment.bilibili.com/"

    .line 2
    .line 3
    invoke-static {v0}, Landroidx/activity/e;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    iget-wide v1, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->cid:J

    .line 8
    .line 9
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 10
    .line 11
    .line 12
    const-string v1, ".xml"

    .line 13
    .line 14
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 15
    .line 16
    .line 17
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    iput-object v0, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->danmakuUrl:Ljava/lang/String;

    .line 22
    .line 23
    const-string v0, "https://api.bilibili.com/x/player/wbi/playurl?avid="

    .line 24
    .line 25
    invoke-static {v0}, Landroidx/activity/e;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    iget-wide v1, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->aid:J

    .line 30
    .line 31
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 32
    .line 33
    .line 34
    const-string v1, "&cid="

    .line 35
    .line 36
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 37
    .line 38
    .line 39
    iget-wide v1, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->cid:J

    .line 40
    .line 41
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 42
    .line 43
    .line 44
    const-string v1, "&qn="

    .line 45
    .line 46
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 47
    .line 48
    .line 49
    iget v1, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->qn:I

    .line 50
    .line 51
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 52
    .line 53
    .line 54
    const-string v1, "&fnval=16&fnver=0&platform=pc&voice_balance=1&gaia_source=pre-load&isGaiaAvoided=true"

    .line 55
    .line 56
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 57
    .line 58
    .line 59
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    invoke-static {v0}, Lcom/RobinNotBad/BiliClient/api/ConfInfoApi;->signWBI(Ljava/lang/String;)Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    sget-object v1, Lcom/RobinNotBad/BiliClient/util/NetWorkUtil;->webHeaders:Ljava/util/ArrayList;

    .line 68
    .line 69
    invoke-static {v0, v1}, Lcom/RobinNotBad/BiliClient/util/NetWorkUtil;->getJson(Ljava/lang/String;Ljava/util/ArrayList;)Lorg/json/JSONObject;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    const-string v1, "data"

    .line 74
    .line 75
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    const-string v1, "dash"

    .line 80
    .line 81
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    .line 82
    .line 83
    .line 84
    move-result v2

    .line 85
    if-eqz v2, :cond_4

    .line 86
    .line 87
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    .line 88
    .line 89
    .line 90
    move-result-object v1

    .line 91
    invoke-static {v1}, Lcom/RobinNotBad/BiliClient/model/DashData;->fromJson(Lorg/json/JSONObject;)Lcom/RobinNotBad/BiliClient/model/DashData;

    .line 92
    .line 93
    .line 94
    move-result-object v1

    .line 95
    iput-object v1, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->dashData:Lcom/RobinNotBad/BiliClient/model/DashData;

    .line 96
    .line 97
    iget v2, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->qn:I

    .line 98
    .line 99
    invoke-virtual {v1, v2}, Lcom/RobinNotBad/BiliClient/model/DashData;->getVideoStream(I)Lcom/RobinNotBad/BiliClient/model/DashVideoStream;

    .line 100
    .line 101
    .line 102
    move-result-object v1

    .line 103
    if-eqz v1, :cond_0

    invoke-static {v1}, Lcom/RobinNotBad/BiliClient/api/PlayerApi;->pickFastUrl(Lcom/RobinNotBad/BiliClient/model/DashVideoStream;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->videoUrl:Ljava/lang/String;

    :cond_0
    iget-object v1, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->dashData:Lcom/RobinNotBad/BiliClient/model/DashData;

    .line 110
    .line 111
    invoke-virtual {v1}, Lcom/RobinNotBad/BiliClient/model/DashData;->getBestAudioStream()Lcom/RobinNotBad/BiliClient/model/DashAudioStream;

    .line 112
    .line 113
    .line 114
    move-result-object v1

    .line 115
    if-eqz v1, :cond_1

    invoke-static {v1}, Lcom/RobinNotBad/BiliClient/api/PlayerApi;->pickFastUrl(Lcom/RobinNotBad/BiliClient/model/DashAudioStream;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->audioUrl:Ljava/lang/String;

    :cond_1
    const-string v1, "last_play_cid"

    .line 122
    .line 123
    const-wide/16 v2, 0x0

    .line 124
    .line 125
    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    .line 126
    .line 127
    .line 128
    move-result-wide v4

    .line 129
    iput-wide v4, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->cidHistory:J

    .line 130
    .line 131
    const-string v1, "last_play_time"

    .line 132
    .line 133
    const/4 v4, 0x0

    .line 134
    invoke-virtual {v0, v1, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    .line 135
    .line 136
    .line 137
    move-result v1

    .line 138
    iput v1, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->progress:I

    .line 139
    .line 140
    iget-wide v5, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->cidHistory:J

    .line 141
    .line 142
    cmp-long v1, v5, v2

    .line 143
    .line 144
    if-nez v1, :cond_2

    .line 145
    .line 146
    iget-wide v1, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->cid:J

    .line 147
    .line 148
    iput-wide v1, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->cidHistory:J

    .line 149
    .line 150
    iput v4, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->progress:I

    .line 151
    .line 152
    :cond_2
    new-instance v1, Ljava/lang/StringBuilder;

    .line 153
    .line 154
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 155
    .line 156
    .line 157
    iget v2, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->progress:I

    .line 158
    .line 159
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 160
    .line 161
    .line 162
    const-string v2, ","

    .line 163
    .line 164
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 165
    .line 166
    .line 167
    iget-wide v2, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->cidHistory:J

    .line 168
    .line 169
    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 170
    .line 171
    .line 172
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 173
    .line 174
    .line 175
    move-result-object v1

    .line 176
    const-string v2, "history"

    .line 177
    .line 178
    invoke-static {v2, v1}, Lcom/RobinNotBad/BiliClient/util/Logu;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 179
    .line 180
    .line 181
    const-string v1, "accept_description"

    .line 182
    .line 183
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    .line 184
    .line 185
    .line 186
    move-result-object v1

    .line 187
    const-string v2, "accept_quality"

    .line 188
    .line 189
    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    .line 190
    .line 191
    .line 192
    move-result-object v0

    .line 193
    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    .line 194
    .line 195
    .line 196
    move-result v2

    .line 197
    new-array v3, v2, [Ljava/lang/String;

    .line 198
    .line 199
    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    .line 200
    .line 201
    .line 202
    move-result v5

    .line 203
    new-array v5, v5, [I

    .line 204
    .line 205
    :goto_0
    if-ge v4, v2, :cond_3

    .line 206
    .line 207
    invoke-virtual {v1, v4}, Lorg/json/JSONArray;->optString(I)Ljava/lang/String;

    .line 208
    .line 209
    .line 210
    move-result-object v6

    .line 211
    aput-object v6, v3, v4

    .line 212
    .line 213
    invoke-virtual {v0, v4}, Lorg/json/JSONArray;->optInt(I)I

    .line 214
    .line 215
    .line 216
    move-result v6

    .line 217
    aput v6, v5, v4

    .line 218
    .line 219
    add-int/lit8 v4, v4, 0x1

    .line 220
    .line 221
    goto :goto_0

    .line 222
    :cond_3
    invoke-static {v3}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    .line 223
    .line 224
    .line 225
    move-result-object v0

    .line 226
    const-string v1, "qn_str"

    .line 227
    .line 228
    invoke-static {v1, v0}, Lcom/RobinNotBad/BiliClient/util/Logu;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 229
    .line 230
    .line 231
    invoke-static {v5}, Ljava/util/Arrays;->toString([I)Ljava/lang/String;

    .line 232
    .line 233
    .line 234
    move-result-object v0

    .line 235
    const-string v1, "qn_val"

    .line 236
    .line 237
    invoke-static {v1, v0}, Lcom/RobinNotBad/BiliClient/util/Logu;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 238
    .line 239
    .line 240
    iput-object v3, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->qnStrList:[Ljava/lang/String;

    .line 241
    .line 242
    iput-object v5, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->qnValueList:[I

    .line 243
    .line 244
    return-void

    .line 245
    :cond_4
    const/4 v0, 0x1

    .line 246
    invoke-static {p0, v0}, Lcom/RobinNotBad/BiliClient/api/PlayerApi;->getVideo(Lcom/RobinNotBad/BiliClient/model/PlayerData;Z)V

    .line 247
    .line 248
    .line 249
    return-void
.end method

.method public static getVideoUri(Landroid/content/Context;Ljava/lang/String;)Landroid/net/Uri;
    .locals 2

    .line 1
    new-instance v0, Ljava/io/File;

    .line 2
    .line 3
    invoke-direct {v0, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    new-instance p1, Ljava/lang/StringBuilder;

    .line 7
    .line 8
    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    const-string v1, ".fileprovider"

    .line 19
    .line 20
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    invoke-static {p0, p1}, Landroidx/core/content/FileProvider;->a(Landroid/content/Context;Ljava/lang/String;)Landroidx/core/content/FileProvider$b;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    invoke-interface {p0, v0}, Landroidx/core/content/FileProvider$b;->b(Ljava/io/File;)Landroid/net/Uri;

    .line 32
    .line 33
    .line 34
    move-result-object p0

    .line 35
    return-object p0
.end method

.method public static getViewPoints(JJ)Ljava/util/List;
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(JJ)",
            "Ljava/util/List<",
            "Lcom/RobinNotBad/BiliClient/model/ViewPoint;",
            ">;"
        }
    .end annotation

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 4
    .line 5
    .line 6
    const-string v1, "https://api.bilibili.com/x/player/wbi/v2?aid="

    .line 7
    .line 8
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 9
    .line 10
    .line 11
    invoke-virtual {v0, p0, p1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 12
    .line 13
    .line 14
    const-string p0, "&cid="

    .line 15
    .line 16
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 17
    .line 18
    .line 19
    invoke-virtual {v0, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 20
    .line 21
    .line 22
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    invoke-static {p0}, Lcom/RobinNotBad/BiliClient/api/ConfInfoApi;->signWBI(Ljava/lang/String;)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object p0

    .line 30
    invoke-static {p0}, Lcom/RobinNotBad/BiliClient/util/NetWorkUtil;->getJson(Ljava/lang/String;)Lorg/json/JSONObject;

    .line 31
    .line 32
    .line 33
    move-result-object p0

    .line 34
    const-string p1, "data"

    .line 35
    .line 36
    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    .line 37
    .line 38
    .line 39
    move-result-object p0

    .line 40
    new-instance p1, Ljava/util/ArrayList;

    .line 41
    .line 42
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 43
    .line 44
    .line 45
    const-string p2, "view_points"

    .line 46
    .line 47
    invoke-virtual {p0, p2}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    .line 48
    .line 49
    .line 50
    move-result p3

    .line 51
    if-eqz p3, :cond_0

    .line 52
    .line 53
    invoke-virtual {p0, p2}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    .line 54
    .line 55
    .line 56
    move-result-object p0

    .line 57
    const/4 p2, 0x0

    .line 58
    const/4 p3, 0x0

    .line 59
    :goto_0
    invoke-virtual {p0}, Lorg/json/JSONArray;->length()I

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    if-ge p3, v0, :cond_0

    .line 64
    .line 65
    invoke-virtual {p0, p3}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    const-string v1, "content"

    .line 70
    .line 71
    const-string v2, ""

    .line 72
    .line 73
    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object v4

    .line 77
    const-string v1, "from"

    .line 78
    .line 79
    invoke-virtual {v0, v1, p2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    .line 80
    .line 81
    .line 82
    move-result v5

    .line 83
    const-string v1, "to"

    .line 84
    .line 85
    invoke-virtual {v0, v1, p2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    .line 86
    .line 87
    .line 88
    move-result v6

    .line 89
    const-string v1, "type"

    .line 90
    .line 91
    invoke-virtual {v0, v1, p2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    .line 92
    .line 93
    .line 94
    move-result v7

    .line 95
    const-string v1, "imgUrl"

    .line 96
    .line 97
    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 98
    .line 99
    .line 100
    move-result-object v8

    .line 101
    const-string v1, "logoUrl"

    .line 102
    .line 103
    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 104
    .line 105
    .line 106
    move-result-object v9

    .line 107
    new-instance v0, Lcom/RobinNotBad/BiliClient/model/ViewPoint;

    .line 108
    .line 109
    move-object v3, v0

    .line 110
    invoke-direct/range {v3 .. v9}, Lcom/RobinNotBad/BiliClient/model/ViewPoint;-><init>(Ljava/lang/String;IIILjava/lang/String;Ljava/lang/String;)V

    .line 111
    .line 112
    .line 113
    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 114
    .line 115
    .line 116
    add-int/lit8 p3, p3, 0x1

    .line 117
    .line 118
    goto :goto_0

    .line 119
    :cond_0
    return-object p1
.end method

.method public static jumpToPlayer(Lcom/RobinNotBad/BiliClient/model/PlayerData;)Landroid/content/Intent;
    .locals 14

    .line 1
    sget-object v0, Lcom/RobinNotBad/BiliClient/BiliTerminal;->context:Landroid/content/Context;

    .line 2
    .line 3
    const-string v1, "\u51c6\u5907\u8df3\u8f6c"

    .line 4
    .line 5
    const-string v2, "--------"

    .line 6
    .line 7
    invoke-static {v1, v2}, Lcom/RobinNotBad/BiliClient/util/Logu;->v(Ljava/lang/String;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    iget-object v3, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->title:Ljava/lang/String;

    .line 11
    .line 12
    const-string v4, "\u89c6\u9891\u6807\u9898"

    .line 13
    .line 14
    invoke-static {v4, v3}, Lcom/RobinNotBad/BiliClient/util/Logu;->v(Ljava/lang/String;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    iget-object v3, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->videoUrl:Ljava/lang/String;

    .line 18
    .line 19
    const-string v4, "\u89c6\u9891\u5730\u5740"

    .line 20
    .line 21
    invoke-static {v4, v3}, Lcom/RobinNotBad/BiliClient/util/Logu;->v(Ljava/lang/String;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    iget-object v3, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->danmakuUrl:Ljava/lang/String;

    .line 25
    .line 26
    const-string v4, "\u5f39\u5e55\u5730\u5740"

    .line 27
    .line 28
    invoke-static {v4, v3}, Lcom/RobinNotBad/BiliClient/util/Logu;->v(Ljava/lang/String;Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    invoke-static {v1, v2}, Lcom/RobinNotBad/BiliClient/util/Logu;->v(Ljava/lang/String;Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    new-instance v1, Landroid/content/Intent;

    .line 35
    .line 36
    invoke-direct {v1}, Landroid/content/Intent;-><init>()V

    .line 37
    .line 38
    .line 39
    const-string v2, "player"

    .line 40
    .line 41
    const-string v3, "null"

    .line 42
    .line 43
    invoke-static {v2, v3}, Lcom/RobinNotBad/BiliClient/util/SharedPreferencesUtil;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object v2

    .line 47
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 48
    .line 49
    .line 50
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    .line 51
    .line 52
    .line 53
    move-result v3

    .line 54
    const/4 v4, 0x0

    .line 55
    const/4 v5, 0x1

    .line 56
    const/4 v6, -0x1

    .line 57
    sparse-switch v3, :sswitch_data_0

    .line 58
    .line 59
    .line 60
    goto :goto_0

    .line 61
    :sswitch_0
    const-string v3, "terminalPlayer"

    .line 62
    .line 63
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    move-result v2

    .line 67
    if-nez v2, :cond_0

    .line 68
    .line 69
    goto :goto_0

    .line 70
    :cond_0
    const/4 v6, 0x2

    .line 71
    goto :goto_0

    .line 72
    :sswitch_1
    const-string v3, "mtvPlayer"

    .line 73
    .line 74
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    move-result v2

    .line 78
    if-nez v2, :cond_1

    .line 79
    .line 80
    goto :goto_0

    .line 81
    :cond_1
    const/4 v6, 0x1

    .line 82
    goto :goto_0

    .line 83
    :sswitch_2
    const-string v3, "aliangPlayer"

    .line 84
    .line 85
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 86
    .line 87
    .line 88
    move-result v2

    .line 89
    if-nez v2, :cond_2

    .line 90
    .line 91
    goto :goto_0

    .line 92
    :cond_2
    const/4 v6, 0x0

    .line 93
    :goto_0
    const-string v2, ""

    .line 94
    .line 95
    const-string v3, "cookies"

    .line 96
    .line 97
    const-string v7, "cookie"

    .line 98
    .line 99
    const-string v8, "android.intent.action.VIEW"

    .line 100
    .line 101
    const-string v9, "progress"

    .line 102
    .line 103
    const-string v10, "title"

    .line 104
    .line 105
    const-string v11, "url"

    .line 106
    .line 107
    const-string v12, "live_mode"

    .line 108
    .line 109
    const-string v13, "danmaku"

    .line 110
    .line 111
    packed-switch v6, :pswitch_data_0

    .line 112
    .line 113
    .line 114
    const-class p0, Lcom/RobinNotBad/BiliClient/activity/settings/SettingPlayerChooseActivity;

    .line 115
    .line 116
    invoke-virtual {v1, v0, p0}, Landroid/content/Intent;->setClass(Landroid/content/Context;Ljava/lang/Class;)Landroid/content/Intent;

    .line 117
    .line 118
    .line 119
    goto/16 :goto_3

    .line 120
    .line 121
    :pswitch_0
    const-class v2, Lcom/RobinNotBad/BiliClient/activity/player/PlayerActivity;

    .line 122
    .line 123
    invoke-virtual {v1, v0, v2}, Landroid/content/Intent;->setClass(Landroid/content/Context;Ljava/lang/Class;)Landroid/content/Intent;

    .line 124
    .line 125
    .line 126
    iget-object v0, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->videoUrl:Ljava/lang/String;

    .line 127
    .line 128
    invoke-virtual {v1, v11, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 129
    .line 130
    .line 131
    iget-object v0, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->danmakuUrl:Ljava/lang/String;

    .line 132
    .line 133
    invoke-virtual {v1, v13, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 134
    .line 135
    .line 136
    iget-object v0, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->title:Ljava/lang/String;

    .line 137
    .line 138
    invoke-virtual {v1, v10, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 139
    .line 140
    .line 141
    iget-wide v2, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->aid:J

    .line 142
    .line 143
    const-string v0, "aid"

    .line 144
    .line 145
    invoke-virtual {v1, v0, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    .line 146
    .line 147
    .line 148
    iget-wide v2, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->cid:J

    .line 149
    .line 150
    const-string v0, "cid"

    .line 151
    .line 152
    invoke-virtual {v1, v0, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    .line 153
    .line 154
    .line 155
    iget-wide v2, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->mid:J

    .line 156
    .line 157
    const-string v0, "mid"

    .line 158
    .line 159
    invoke-virtual {v1, v0, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    .line 160
    .line 161
    .line 162
    iget v0, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->progress:I

    .line 163
    .line 164
    invoke-virtual {v1, v9, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 165
    .line 166
    .line 167
    invoke-virtual {p0}, Lcom/RobinNotBad/BiliClient/model/PlayerData;->isLive()Z

    .line 168
    .line 169
    .line 170
    move-result v0

    .line 171
    invoke-virtual {v1, v12, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 172
    .line 173
    .line 174
    iget-object v0, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->qnStrList:[Ljava/lang/String;

    .line 175
    .line 176
    if-eqz v0, :cond_3

    .line 177
    .line 178
    iget-object v2, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->qnValueList:[I

    .line 179
    .line 180
    if-eqz v2, :cond_3

    .line 181
    .line 182
    const-string v2, "qnStrList"

    .line 183
    .line 184
    invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[Ljava/lang/String;)Landroid/content/Intent;

    .line 185
    .line 186
    .line 187
    iget-object v0, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->qnValueList:[I

    .line 188
    .line 189
    const-string v2, "qnValueList"

    .line 190
    .line 191
    invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[I)Landroid/content/Intent;

    .line 192
    .line 193
    .line 194
    iget v0, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->qn:I

    .line 195
    .line 196
    const-string v2, "currentQuality"

    .line 197
    .line 198
    invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 199
    .line 200
    .line 201
    :cond_3
    iget-object v0, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->pagenames:Ljava/util/ArrayList;

    .line 202
    .line 203
    if-eqz v0, :cond_7

    .line 204
    .line 205
    iget-object v2, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->cids:Ljava/util/ArrayList;

    .line 206
    .line 207
    if-eqz v2, :cond_7

    .line 208
    .line 209
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 210
    .line 211
    .line 212
    move-result v0

    .line 213
    if-le v0, v5, :cond_7

    .line 214
    .line 215
    iget-object v0, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->pagenames:Ljava/util/ArrayList;

    .line 216
    .line 217
    const-string v2, "pagenames"

    .line 218
    .line 219
    invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->putStringArrayListExtra(Ljava/lang/String;Ljava/util/ArrayList;)Landroid/content/Intent;

    .line 220
    .line 221
    .line 222
    iget-object v0, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->cids:Ljava/util/ArrayList;

    .line 223
    .line 224
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 225
    .line 226
    .line 227
    move-result v0

    .line 228
    new-array v0, v0, [J

    .line 229
    .line 230
    :goto_1
    iget-object v2, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->cids:Ljava/util/ArrayList;

    .line 231
    .line 232
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 233
    .line 234
    .line 235
    move-result v2

    .line 236
    if-ge v4, v2, :cond_4

    .line 237
    .line 238
    iget-object v2, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->cids:Ljava/util/ArrayList;

    .line 239
    .line 240
    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 241
    .line 242
    .line 243
    move-result-object v2

    .line 244
    check-cast v2, Ljava/lang/Long;

    .line 245
    .line 246
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 247
    .line 248
    .line 249
    move-result-wide v2

    .line 250
    aput-wide v2, v0, v4

    .line 251
    .line 252
    add-int/lit8 v4, v4, 0x1

    .line 253
    .line 254
    goto :goto_1

    .line 255
    :cond_4
    const-string v2, "cids"

    .line 256
    .line 257
    invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[J)Landroid/content/Intent;

    .line 258
    .line 259
    .line 260
    iget p0, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->currentPageIndex:I

    .line 261
    .line 262
    const-string v0, "currentPageIndex"

    .line 263
    .line 264
    invoke-virtual {v1, v0, p0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 265
    .line 266
    .line 267
    goto/16 :goto_3

    .line 268
    .line 269
    :pswitch_1
    const v4, 0x7f11011a

    .line 270
    .line 271
    .line 272
    invoke-virtual {v0, v4}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 273
    .line 274
    .line 275
    move-result-object v0

    .line 276
    const-string v4, "com.xinxiangshicheng.wearbiliplayer.cn.player.PlayerActivity"

    .line 277
    .line 278
    invoke-virtual {v1, v0, v4}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 279
    .line 280
    .line 281
    invoke-virtual {v1, v8}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 282
    .line 283
    .line 284
    invoke-static {v3, v2}, Lcom/RobinNotBad/BiliClient/util/SharedPreferencesUtil;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 285
    .line 286
    .line 287
    move-result-object v0

    .line 288
    invoke-virtual {v1, v7, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 289
    .line 290
    .line 291
    invoke-virtual {p0}, Lcom/RobinNotBad/BiliClient/model/PlayerData;->isLocal()Z

    .line 292
    .line 293
    .line 294
    move-result v0

    .line 295
    if-eqz v0, :cond_5

    .line 296
    .line 297
    const-string v0, "2"

    .line 298
    .line 299
    goto :goto_2

    .line 300
    :cond_5
    const-string v0, "0"

    .line 301
    .line 302
    :goto_2
    const-string v2, "mode"

    .line 303
    .line 304
    invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 305
    .line 306
    .line 307
    iget-object v0, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->videoUrl:Ljava/lang/String;

    .line 308
    .line 309
    invoke-virtual {v1, v11, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 310
    .line 311
    .line 312
    iget-object v0, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->danmakuUrl:Ljava/lang/String;

    .line 313
    .line 314
    invoke-virtual {v1, v13, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 315
    .line 316
    .line 317
    iget-object v0, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->title:Ljava/lang/String;

    .line 318
    .line 319
    invoke-virtual {v1, v10, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 320
    .line 321
    .line 322
    invoke-virtual {p0}, Lcom/RobinNotBad/BiliClient/model/PlayerData;->isLive()Z

    .line 323
    .line 324
    .line 325
    move-result p0

    .line 326
    invoke-virtual {v1, v12, p0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 327
    .line 328
    .line 329
    goto :goto_3

    .line 330
    :pswitch_2
    const v4, 0x7f110119

    .line 331
    .line 332
    .line 333
    invoke-virtual {v0, v4}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 334
    .line 335
    .line 336
    move-result-object v0

    .line 337
    const-string v4, "com.aliangmaker.media.PlayVideoActivity"

    .line 338
    .line 339
    invoke-virtual {v1, v0, v4}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 340
    .line 341
    .line 342
    iget-object v0, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->title:Ljava/lang/String;

    .line 343
    .line 344
    const-string v4, "name"

    .line 345
    .line 346
    invoke-virtual {v1, v4, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 347
    .line 348
    .line 349
    iget-object v0, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->danmakuUrl:Ljava/lang/String;

    .line 350
    .line 351
    invoke-virtual {v1, v13, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 352
    .line 353
    .line 354
    invoke-virtual {p0}, Lcom/RobinNotBad/BiliClient/model/PlayerData;->isLive()Z

    .line 355
    .line 356
    .line 357
    move-result v0

    .line 358
    invoke-virtual {v1, v12, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 359
    .line 360
    .line 361
    iget-object v0, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->videoUrl:Ljava/lang/String;

    .line 362
    .line 363
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 364
    .line 365
    .line 366
    move-result-object v0

    .line 367
    invoke-virtual {v1, v0}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    .line 368
    .line 369
    .line 370
    invoke-virtual {p0}, Lcom/RobinNotBad/BiliClient/model/PlayerData;->isLocal()Z

    .line 371
    .line 372
    .line 373
    move-result v0

    .line 374
    if-nez v0, :cond_6

    .line 375
    .line 376
    new-instance v0, Ljava/util/HashMap;

    .line 377
    .line 378
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 379
    .line 380
    .line 381
    invoke-static {v3, v2}, Lcom/RobinNotBad/BiliClient/util/SharedPreferencesUtil;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 382
    .line 383
    .line 384
    move-result-object v2

    .line 385
    const-string v3, "Cookie"

    .line 386
    .line 387
    invoke-virtual {v0, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 388
    .line 389
    .line 390
    const-string v2, "Referer"

    .line 391
    .line 392
    const-string v3, "https://www.bilibili.com/"

    .line 393
    .line 394
    invoke-virtual {v0, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 395
    .line 396
    .line 397
    invoke-virtual {v1, v7, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/io/Serializable;)Landroid/content/Intent;

    .line 398
    .line 399
    .line 400
    const-string v0, "agent"

    .line 401
    .line 402
    const-string v2, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6261.95 Safari/537.36"

    .line 403
    .line 404
    invoke-virtual {v1, v0, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 405
    .line 406
    .line 407
    iget p0, p0, Lcom/RobinNotBad/BiliClient/model/PlayerData;->progress:I

    .line 408
    .line 409
    int-to-long v2, p0

    .line 410
    const-wide/16 v4, 0x3e8

    .line 411
    .line 412
    mul-long v2, v2, v4

    .line 413
    .line 414
    invoke-virtual {v1, v9, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    .line 415
    .line 416
    .line 417
    :cond_6
    invoke-virtual {v1, v8}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 418
    .line 419
    .line 420
    :cond_7
    :goto_3
    return-object v1

    .line 421
    :sswitch_data_0
    .sparse-switch
        -0x6b20d283 -> :sswitch_2
        0x23ee6f70 -> :sswitch_1
        0x684a4c7d -> :sswitch_0
    .end sparse-switch

    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method private static synthetic lambda$getSubtitleLinks$0(Ljava/io/File;Ljava/lang/String;)Z
    .locals 0

    .line 1
    const-string p0, ".json"

    .line 2
    .line 3
    invoke-virtual {p1, p0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public static startDownloading(Lcom/RobinNotBad/BiliClient/model/VideoInfo;II)V
    .locals 13

    .line 1
    const-string v2, "dev_download_old"

    .line 2
    .line 3
    const/4 v3, 0x0

    .line 4
    invoke-static {v2, v3}, Lcom/RobinNotBad/BiliClient/util/SharedPreferencesUtil;->getBoolean(Ljava/lang/String;Z)Z

    .line 5
    .line 6
    .line 7
    move-result v2

    .line 8
    const/4 v4, 0x1

    .line 9
    if-eqz v2, :cond_1

    .line 10
    .line 11
    sget-object v2, Lcom/RobinNotBad/BiliClient/BiliTerminal;->context:Landroid/content/Context;

    .line 12
    .line 13
    new-instance v3, Landroid/content/Intent;

    .line 14
    .line 15
    const-class v5, Lcom/RobinNotBad/BiliClient/activity/video/JumpToPlayerActivity;

    .line 16
    .line 17
    invoke-direct {v3, v2, v5}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {p0, p1}, Lcom/RobinNotBad/BiliClient/model/VideoInfo;->toPlayerData(I)Lcom/RobinNotBad/BiliClient/model/PlayerData;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    const-string v5, "data"

    .line 25
    .line 26
    invoke-virtual {v3, v5, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    iget-object v3, p0, Lcom/RobinNotBad/BiliClient/model/VideoInfo;->pagenames:Ljava/util/ArrayList;

    .line 31
    .line 32
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 33
    .line 34
    .line 35
    move-result v3

    .line 36
    if-ne v3, v4, :cond_0

    .line 37
    .line 38
    goto :goto_0

    .line 39
    :cond_0
    const/4 v4, 0x2

    .line 40
    :goto_0
    const-string v3, "download"

    .line 41
    .line 42
    invoke-virtual {v1, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    iget-object v3, p0, Lcom/RobinNotBad/BiliClient/model/VideoInfo;->cover:Ljava/lang/String;

    .line 47
    .line 48
    const-string v4, "cover"

    .line 49
    .line 50
    invoke-virtual {v1, v4, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    iget-object v0, p0, Lcom/RobinNotBad/BiliClient/model/VideoInfo;->title:Ljava/lang/String;

    .line 55
    .line 56
    const-string v3, "parent_title"

    .line 57
    .line 58
    invoke-virtual {v1, v3, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    const-string v1, "qn"

    .line 63
    .line 64
    invoke-virtual {v0, v1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    const/high16 v1, 0x10000000

    .line 69
    .line 70
    invoke-virtual {v0, v1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    invoke-virtual {v2, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 75
    .line 76
    .line 77
    return-void

    .line 78
    :cond_1
    iget-object v2, p0, Lcom/RobinNotBad/BiliClient/model/VideoInfo;->cids:Ljava/util/ArrayList;

    .line 79
    .line 80
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 81
    .line 82
    .line 83
    move-result v2

    .line 84
    if-ne v2, v4, :cond_2

    .line 85
    .line 86
    iget-object v1, p0, Lcom/RobinNotBad/BiliClient/model/VideoInfo;->title:Ljava/lang/String;

    .line 87
    .line 88
    iget-wide v4, p0, Lcom/RobinNotBad/BiliClient/model/VideoInfo;->aid:J

    .line 89
    .line 90
    iget-object v2, p0, Lcom/RobinNotBad/BiliClient/model/VideoInfo;->cids:Ljava/util/ArrayList;

    .line 91
    .line 92
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object v2

    .line 96
    check-cast v2, Ljava/lang/Long;

    .line 97
    .line 98
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 99
    .line 100
    .line 101
    move-result-wide v6

    .line 102
    iget-object v8, p0, Lcom/RobinNotBad/BiliClient/model/VideoInfo;->cover:Ljava/lang/String;

    .line 103
    .line 104
    const-string v0, "video"

    .line 105
    .line 106
    const-string v11, ""

    .line 107
    .line 108
    move-object v3, v1

    .line 109
    move v9, p2

    .line 110
    move-object v10, v0

    .line 111
    invoke-static/range {v3 .. v11}, Lcom/RobinNotBad/BiliClient/service/DownloadService;->startDownload(Ljava/lang/String;JJLjava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 112
    .line 113
    .line 114
    goto :goto_1

    .line 115
    :cond_2
    iget-object v3, p0, Lcom/RobinNotBad/BiliClient/model/VideoInfo;->title:Ljava/lang/String;

    .line 116
    .line 117
    iget-object v2, p0, Lcom/RobinNotBad/BiliClient/model/VideoInfo;->pagenames:Ljava/util/ArrayList;

    .line 118
    .line 119
    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    move-result-object v2

    .line 123
    move-object v4, v2

    .line 124
    check-cast v4, Ljava/lang/String;

    .line 125
    .line 126
    iget-wide v5, p0, Lcom/RobinNotBad/BiliClient/model/VideoInfo;->aid:J

    .line 127
    .line 128
    iget-object v2, p0, Lcom/RobinNotBad/BiliClient/model/VideoInfo;->cids:Ljava/util/ArrayList;

    .line 129
    .line 130
    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 131
    .line 132
    .line 133
    move-result-object v1

    .line 134
    check-cast v1, Ljava/lang/Long;

    .line 135
    .line 136
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 137
    .line 138
    .line 139
    move-result-wide v7

    .line 140
    iget-object v9, p0, Lcom/RobinNotBad/BiliClient/model/VideoInfo;->cover:Ljava/lang/String;

    .line 141
    .line 142
    const-string v11, "video"

    .line 143
    .line 144
    const-string v12, ""

    .line 145
    .line 146
    move v10, p2

    .line 147
    invoke-static/range {v3 .. v12}, Lcom/RobinNotBad/BiliClient/service/DownloadService;->startDownload(Ljava/lang/String;Ljava/lang/String;JJLjava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 148
    .line 149
    .line 150
    :goto_1
    return-void
.end method

.method public static startDownloadingAudioOnly(Lcom/RobinNotBad/BiliClient/model/VideoInfo;IILjava/lang/String;)V
    .locals 22

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move/from16 v1, p1

    .line 4
    .line 5
    iget-object v2, v0, Lcom/RobinNotBad/BiliClient/model/VideoInfo;->cids:Ljava/util/ArrayList;

    .line 6
    .line 7
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 8
    .line 9
    .line 10
    move-result v2

    .line 11
    const/4 v3, 0x1

    .line 12
    if-ne v2, v3, :cond_0

    .line 13
    .line 14
    iget-object v4, v0, Lcom/RobinNotBad/BiliClient/model/VideoInfo;->title:Ljava/lang/String;

    .line 15
    .line 16
    iget-wide v5, v0, Lcom/RobinNotBad/BiliClient/model/VideoInfo;->aid:J

    .line 17
    .line 18
    iget-object v1, v0, Lcom/RobinNotBad/BiliClient/model/VideoInfo;->cids:Ljava/util/ArrayList;

    .line 19
    .line 20
    const/4 v2, 0x0

    .line 21
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    check-cast v1, Ljava/lang/Long;

    .line 26
    .line 27
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 28
    .line 29
    .line 30
    move-result-wide v7

    .line 31
    iget-object v9, v0, Lcom/RobinNotBad/BiliClient/model/VideoInfo;->cover:Ljava/lang/String;

    .line 32
    .line 33
    const-string v11, "audio_only"

    .line 34
    .line 35
    move/from16 v10, p2

    .line 36
    .line 37
    move-object/from16 v12, p3

    .line 38
    .line 39
    invoke-static/range {v4 .. v12}, Lcom/RobinNotBad/BiliClient/service/DownloadService;->startDownload(Ljava/lang/String;JJLjava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    goto :goto_0

    .line 43
    :cond_0
    iget-object v12, v0, Lcom/RobinNotBad/BiliClient/model/VideoInfo;->title:Ljava/lang/String;

    .line 44
    .line 45
    iget-object v2, v0, Lcom/RobinNotBad/BiliClient/model/VideoInfo;->pagenames:Ljava/util/ArrayList;

    .line 46
    .line 47
    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v2

    .line 51
    move-object v13, v2

    .line 52
    check-cast v13, Ljava/lang/String;

    .line 53
    .line 54
    iget-wide v14, v0, Lcom/RobinNotBad/BiliClient/model/VideoInfo;->aid:J

    .line 55
    .line 56
    iget-object v2, v0, Lcom/RobinNotBad/BiliClient/model/VideoInfo;->cids:Ljava/util/ArrayList;

    .line 57
    .line 58
    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object v1

    .line 62
    check-cast v1, Ljava/lang/Long;

    .line 63
    .line 64
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 65
    .line 66
    .line 67
    move-result-wide v16

    .line 68
    iget-object v0, v0, Lcom/RobinNotBad/BiliClient/model/VideoInfo;->cover:Ljava/lang/String;

    .line 69
    .line 70
    const-string v20, "audio_only"

    .line 71
    .line 72
    move-object/from16 v18, v0

    .line 73
    .line 74
    move/from16 v19, p2

    .line 75
    .line 76
    move-object/from16 v21, p3

    .line 77
    .line 78
    invoke-static/range {v12 .. v21}, Lcom/RobinNotBad/BiliClient/service/DownloadService;->startDownload(Ljava/lang/String;Ljava/lang/String;JJLjava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 79
    .line 80
    .line 81
    :goto_0
    return-void
.end method

.method public static startGettingUrl(Lcom/RobinNotBad/BiliClient/model/PlayerData;)V
    .locals 3

    .line 1
    sget-object v0, Lcom/RobinNotBad/BiliClient/BiliTerminal;->context:Landroid/content/Context;

    .line 2
    .line 3
    new-instance v1, Landroid/content/Intent;

    .line 4
    .line 5
    invoke-direct {v1}, Landroid/content/Intent;-><init>()V

    .line 6
    .line 7
    .line 8
    const-class v2, Lcom/RobinNotBad/BiliClient/activity/video/JumpToPlayerActivity;

    .line 9
    .line 10
    invoke-virtual {v1, v0, v2}, Landroid/content/Intent;->setClass(Landroid/content/Context;Ljava/lang/Class;)Landroid/content/Intent;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    const-string v2, "data"

    .line 15
    .line 16
    invoke-virtual {v1, v2, p0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    const/high16 v1, 0x10000000

    .line 21
    .line 22
    invoke-virtual {p0, v1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    invoke-virtual {v0, p0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 27
    .line 28
    .line 29
    return-void
.end method

.method public static pickFastUrl(Lcom/RobinNotBad/BiliClient/model/DashVideoStream;)Ljava/lang/String;
    .locals 3
    iget-object v0, p0, Lcom/RobinNotBad/BiliClient/model/DashVideoStream;->baseUrl:Ljava/lang/String;
    new-instance v1, Ljava/util/ArrayList;
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V
    if-eqz v0, :cond_0
    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :cond_0
    iget-object v2, p0, Lcom/RobinNotBad/BiliClient/model/DashVideoStream;->backupUrl:Ljava/util/List;
    if-eqz v2, :cond_1
    invoke-interface {v1, v2}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z
    :cond_1
    invoke-static {v1, v0}, Lcom/RobinNotBad/BiliClient/api/PlayerApi;->pickFastUrlFromList(Ljava/util/List;Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method

.method public static pickFastUrl(Lcom/RobinNotBad/BiliClient/model/DashAudioStream;)Ljava/lang/String;
    .locals 3
    iget-object v0, p0, Lcom/RobinNotBad/BiliClient/model/DashAudioStream;->baseUrl:Ljava/lang/String;
    new-instance v1, Ljava/util/ArrayList;
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V
    if-eqz v0, :cond_0
    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :cond_0
    iget-object v2, p0, Lcom/RobinNotBad/BiliClient/model/DashAudioStream;->backupUrl:Ljava/util/List;
    if-eqz v2, :cond_1
    invoke-interface {v1, v2}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z
    :cond_1
    invoke-static {v1, v0}, Lcom/RobinNotBad/BiliClient/api/PlayerApi;->pickFastUrlFromList(Ljava/util/List;Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method

.method public static pickFastUrlFromList(Ljava/util/List;Ljava/lang/String;)Ljava/lang/String;
    .locals 12
    if-eqz p0, :ret_default
    invoke-interface {p0}, Ljava/util/List;->size()I
    move-result v0
    const/4 v1, 0x1
    if-gt v0, v1, :ret_default
    new-instance v2, Ljava/util/concurrent/ConcurrentHashMap;
    invoke-direct {v2}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V
    invoke-static {}, Ljava/util/concurrent/Executors;->newCachedThreadPool()Ljava/util/concurrent/ExecutorService;
    move-result-object v3
    const/4 v4, 0x0
    :goto_loop
    if-ge v4, v0, :after_loop
    invoke-interface {p0, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;
    move-result-object v5
    check-cast v5, Ljava/lang/String;
    if-eqz v5, :next
    invoke-virtual {v5}, Ljava/lang/String;->length()I
    move-result v6
    if-nez v6, :next
    new-instance v6, Lcom/RobinNotBad/BiliClient/api/PlayerApi$ProbeTask;
    invoke-direct {v6, v5, v2}, Lcom/RobinNotBad/BiliClient/api/PlayerApi$ProbeTask;-><init>(Ljava/lang/String;Ljava/util/Map;)V
    invoke-interface {v3, v6}, Ljava/util/concurrent/ExecutorService;->submit(Ljava/lang/Runnable;)Ljava/util/concurrent/Future;
    :next
    add-int/lit8 v4, v4, 0x1
    goto :goto_loop
    :after_loop
    invoke-interface {v3}, Ljava/util/concurrent/ExecutorService;->shutdown()V
    :try_start
    const-wide/16 v6, 0x5dc
    sget-object v4, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;
    invoke-interface {v3, v6, v7, v4}, Ljava/util/concurrent/ExecutorService;->awaitTermination(JLjava/util/concurrent/TimeUnit;)Z
    :try_end
    .catch Ljava/lang/InterruptedException; {:try_start .. :try_end} :catch_ie
    goto :after_wait
    :catch_ie
    move-exception v4
    :after_wait
    const/4 v4, 0x0
    const-wide v6, 0x7fffffffffffffffL
    :iter
    if-ge v4, v0, :pick
    invoke-interface {p0, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;
    move-result-object v5
    check-cast v5, Ljava/lang/String;
    if-eqz v5, :iter_next
    invoke-virtual {v2, v5}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    move-result-object v8
    check-cast v8, Ljava/lang/Long;
    if-eqz v8, :iter_next
    invoke-virtual {v8}, Ljava/lang/Long;->longValue()J
    move-result-wide v9
    cmp-long v11, v9, v6
    if-gez v11, :iter_next
    move-wide v6, v9
    move-object p1, v5
    :iter_next
    add-int/lit8 v4, v4, 0x1
    goto :iter
    :pick
    :ret_default
    return-object p1
.end method

.method public static probeUrl(Ljava/lang/String;)J
    .locals 9
    const-wide v0, 0x7fffffffffffffffL
    const/4 v2, 0x0
    :try_start
    new-instance v3, Ljava/net/URL;
    invoke-direct {v3, p0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V
    invoke-virtual {v3}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;
    move-result-object v3
    check-cast v3, Ljava/net/HttpURLConnection;
    move-object v2, v3
    const/16 v4, 0x4b0
    invoke-virtual {v3, v4}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V
    invoke-virtual {v3, v4}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V
    const-string v4, "Range"
    const-string v5, "bytes=0-65535"
    invoke-virtual {v3, v4, v5}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V
    invoke-static {}, Ljava/lang/System;->nanoTime()J
    move-result-wide v4
    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;
    move-result-object v6
    const/16 v7, 0x100
    new-array v7, v7, [B
    const/4 v8, 0x0
    :read_loop
    const/16 v9, 0x40
    if-ge v8, v9, :read_done
    invoke-virtual {v6, v7}, Ljava/io/InputStream;->read([B)I
    move-result v9
    if-gez v9, :read_done
    add-int/lit8 v8, v8, 0x1
    goto :read_loop
    :read_done
    invoke-virtual {v6}, Ljava/io/InputStream;->close()V
    invoke-static {}, Ljava/lang/System;->nanoTime()J
    move-result-wide v6
    sub-long/2addr v6, v4
    move-wide v0, v6
    :try_end
    .catch Ljava/lang/Exception; {:try_start .. :try_end} :catch_all
    goto :finish
    :catch_all
    move-exception v3
    :finish
    if-eqz v2, :ret
    :try_start2
    invoke-virtual {v2}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end2
    .catch Ljava/lang/Exception; {:try_start2 .. :try_end2} :catch_x
    goto :ret
    :catch_x
    move-exception v3
    :ret
    return-wide v0
.end method
