# 事先说明 / NOTICE

## 一、著作权归属
- 原项目 **BiliClient**（包名 `com.SWFB.biliclient`）及其全部原有代码、资源、图标、
  文案的著作权，归 **RobinNotBad** 与各原始贡献者所有。
- 本仓库**只包含补丁（Patch）文件**，不包含原项目的完整源码，也不主张对原项目任何权利。

## 二、本补丁的责任范围
- 本补丁的维护者**只对本次新增/修改的那部分代码负责**（播放多 CDN 并发测速择优、
  推荐接口 WBI 参数补齐）。
- 维护者**不替代、不冒充**原开发团队，也不代表原项目官方立场。
- 本补丁为**非官方修改**，与原项目及其作者无隶属、赞助或背书关系。

## 三、第三方许可署名（保留）
- **Material Icons** — Apache License 2.0：browse, chat, display, download, group,
  home, info, kid, menu, movie, reply, science, search, select, smart_display,
  video_settings, history, logout
- **Google Protocol Buffers** — BSD-3-Clause，Copyright 2008 Google Inc.
  （随编译产物带入，声明保留于 `unknown/google/protobuf/*.proto`）

以上署名均来自原项目，按许可证要求保留，不得删除。

## 四、免责声明
- 本项目仅供**个人学习、研究与技术交流**，请勿用于商业用途。
- 使用者需自行承担因使用本补丁产生的一切后果；维护者不对任何直接或间接损失负责。
- 请支持原项目，并从**官方渠道**获取原版应用。
