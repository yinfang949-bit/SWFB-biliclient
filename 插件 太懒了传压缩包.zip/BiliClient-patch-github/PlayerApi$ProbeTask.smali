.class Lcom/RobinNotBad/BiliClient/api/PlayerApi$ProbeTask;
.super Ljava/lang/Object;
.source "PlayerApi.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field private final map:Ljava/util/Map;

.field private final url:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/util/Map;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/RobinNotBad/BiliClient/api/PlayerApi$ProbeTask;->url:Ljava/lang/String;

    iput-object p2, p0, Lcom/RobinNotBad/BiliClient/api/PlayerApi$ProbeTask;->map:Ljava/util/Map;

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    :try_start
    iget-object v0, p0, Lcom/RobinNotBad/BiliClient/api/PlayerApi$ProbeTask;->url:Ljava/lang/String;

    invoke-static {v0}, Lcom/RobinNotBad/BiliClient/api/PlayerApi;->probeUrl(Ljava/lang/String;)J

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    iget-object v2, p0, Lcom/RobinNotBad/BiliClient/api/PlayerApi$ProbeTask;->map:Ljava/util/Map;

    iget-object v3, p0, Lcom/RobinNotBad/BiliClient/api/PlayerApi$ProbeTask;->url:Ljava/lang/String;

    invoke-interface {v2, v3, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :try_end
    .catch Ljava/lang/Exception; {:try_start .. :try_end} :catch_all

    goto :finish

    :catch_all
    move-exception v0

    :finish
    return-void
.end method
